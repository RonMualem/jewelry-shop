# Jewelry Shop (Next.js)

חנות תכשיטים אלגנטית עם הזמנה מהירה ב־WhatsApp.

## הגדרה מהירה
1. ערוך את הקובץ `app/page.jsx` ושנה את `WHATSAPP_PHONE` למספר שלך בפורמט בינלאומי (ישראל: 9725XXXXXXX).
2. הוסף/עדכן מוצרים במערך `PRODUCTS` באותו קובץ.
3. פריסה ל-Vercel: חבר את הריפו, ולחץ Deploy.

